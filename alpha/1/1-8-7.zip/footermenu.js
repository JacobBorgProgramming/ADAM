
function footermenu(){

    document.getElementById("footermenu").innerHTML = '    <center><p>© Jacob Borg 2023</p> <p> <a href="./about.html">About</a><a style="margin-left: 15px;" href="./mememaker.html">Meme Maker</a><a style="margin-left: 15px;" href="./changelog.html">Change Log</a><a style="margin-left: 15px;" href="https://github.com/JacobBorgProgramming/ADAM" target="_blank">Github</a> </p> <p> <a href="https://bulma.io/" target="_blank"> <img style="margin-top: 15px;" width="150px" src="./made-with-bulma--white.png"> </a> </p> </center>'

}




