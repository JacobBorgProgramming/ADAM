
function privacystatement(){

    document.getElementById("privacy").innerHTML = '<article style="margin-top: 25px; margin-bottom: 25px" class="message"><div class="message-body">By using ADAM, you are cool with our privacy stuff (You agree and approve of our privacy practices). <a href="./privacy.html"><strong>Read about privacy and ADAM</strong></a></div></article>'
//    document.getElementById("counter").innerHTML = '<script src="https://cdn.counter.dev/script.js" data-id="e723b406-567b-475d-be1b-651ca897c0da" data-utcoffset="-7"></script>'

}
